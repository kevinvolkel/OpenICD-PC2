//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ICD_BS.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_BS.h"
#include "VTC_cor.h"
#include "dis_AFib.h"
#include "dis_STB.h"
#include "dis_VTC.h"
#include "dis_VgtA.h"

// Function Definitions

//
// Initialization and resets
// Arguments    : struct0_T *ICD_state
//                const struct2_T *ICD_param
//                double A_sense
//                double V_sense
//                double V_shock
//                double *therapy
//                double *inhibit
// Return Type  : void
//
void ICD_BS(struct4_T *ICD_state, const struct2_T *ICD_param, double A_sense,
            double V_sense, double V_shock, double *therapy, double *inhibit)
{
  int idx;
  double fcc;
  boolean_T x[10];
  int ii;
  boolean_T exitg6;
  boolean_T guard6 = false;
  int i2;
  boolean_T exitg5;
  boolean_T guard5 = false;
  int i3;
  boolean_T exitg4;
  boolean_T guard4 = false;
  int i4;
  boolean_T exitg3;
  boolean_T guard3 = false;
  int i5;
  double y;
  double s;
  double b_x[10];
  double d;
  double c_x;
  boolean_T guard1 = false;
  boolean_T exitg2;
  boolean_T guard2 = false;
  int i6;
  boolean_T exitg1;
  boolean_T b_guard1 = false;
  int i7;
  ICD_state->VT = 0.0;
  ICD_state->VF = 0.0;
  ICD_state->VS = 0.0;
  ICD_state->VBlk = 0.0;
  ICD_state->ABlk = 0.0;
  ICD_state->AR = 0.0;
  ICD_state->AS = 0.0;

  //      A_sense=0;
  //      V_sense=0;
  *therapy = 0.0;
  *inhibit = 0.0;

  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  //  Time elapse
  //  The only place where counters are increased
  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  ICD_state->A_clk++;
  ICD_state->V_clk++;
  if (ICD_state->VTC_ind < 201.0) {
    //      ICD_state.VTC_morph=[ICD_state.VTC_morph,V_shock];
    ICD_state->VTC_morph[(int)ICD_state->VTC_ind - 1] = V_shock;
    ICD_state->VTC_ind++;
  } else {
    //       ICD_state.VTC_morph(1)=[];
    //       ICD_state.VTC_morph=[ICD_state.VTC_morph,V_shock];
    for (idx = 0; idx < 199; idx++) {
      ICD_state->VTC_morph[idx] = ICD_state->VTC_morph[1 + idx];
    }

    ICD_state->VTC_morph[199] = V_shock;
  }

  if ((ICD_state->V_clk == 100.0) && (ICD_state->VTC_ind >= 201.0)) {
    VTC_cor(ICD_state->VTC_morph, &ICD_state->NSR_temp, &ICD_state->VTC_win[9],
            &fcc);
  }

  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  //  Sensing
  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  // [A_sense,V_sense,ICD_state]=ICD_sensing(A_in,V_in,ICD_state,ICD_param);
  //  During VFduration, count to 10
  if (ICD_state->VFduration != 0.0) {
    ICD_state->VFdur_count++;
    for (idx = 0; idx < 10; idx++) {
      x[idx] = (ICD_state->V_win[idx] < ICD_param->VF_thresh);
    }

    idx = 0;
    ii = 1;
    exitg6 = false;
    while ((!exitg6) && (ii < 11)) {
      guard6 = false;
      if (x[ii - 1]) {
        idx++;
        if (idx >= 10) {
          exitg6 = true;
        } else {
          guard6 = true;
        }
      } else {
        guard6 = true;
      }

      if (guard6) {
        ii++;
      }
    }

    if (1 > idx) {
      i2 = 0;
    } else {
      i2 = idx;
    }

    if ((i2 < 6) || (ICD_state->V_win[9] > ICD_param->VF_thresh)) {
      ICD_state->VFduration = 0.0;
      *inhibit = 1.0;

      // message=[message;{['t=',num2str(ICD_state.g_clk),',VF duration drop-off']}]; 
    }

    //  Duration finishes
    if (ICD_state->VFdur_count >= ICD_param->VFdur_length) {
      //  Reset durations
      ICD_state->VFduration = 0.0;
      ICD_state->VFdur_count = 0.0;

      //  If less than 6/10 beats during duration or the last beat is slower
      //  than VF threshold, cancel episode.
      for (idx = 0; idx < 10; idx++) {
        x[idx] = (ICD_state->V_win[idx] < ICD_param->VF_thresh);
      }

      idx = 0;
      ii = 1;
      exitg5 = false;
      while ((!exitg5) && (ii < 11)) {
        guard5 = false;
        if (x[ii - 1]) {
          idx++;
          if (idx >= 10) {
            exitg5 = true;
          } else {
            guard5 = true;
          }
        } else {
          guard5 = true;
        }

        if (guard5) {
          ii++;
        }
      }

      if (1 > idx) {
        i3 = 0;
      } else {
        i3 = idx;
      }

      if ((i3 < 6) || (ICD_state->V_win[9] > ICD_param->VF_thresh)) {
        //  Do nothing, cancel episode
        // message=[message;{['t=',num2str(ICD_state.g_clk),',VF duration finish but inhibit']}]; 
      } else {
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%
        //  ATP and shock
        // %%%%%%%%%%%%%%%%%%%%%%%%%
        //  Todo
        *therapy = 1.0;

        // message=[message;{['t=',num2str(ICD_state.g_clk),',VF therapy']}];
      }
    }
  }

  //  During VTduration, count to 10
  if (ICD_state->VTduration != 0.0) {
    ICD_state->VTdur_count++;
    for (idx = 0; idx < 10; idx++) {
      x[idx] = (ICD_state->V_win[idx] < ICD_param->VT_thresh);
    }

    idx = 0;
    ii = 1;
    exitg4 = false;
    while ((!exitg4) && (ii < 11)) {
      guard4 = false;
      if (x[ii - 1]) {
        idx++;
        if (idx >= 10) {
          exitg4 = true;
        } else {
          guard4 = true;
        }
      } else {
        guard4 = true;
      }

      if (guard4) {
        ii++;
      }
    }

    if (1 > idx) {
      i4 = 0;
    } else {
      i4 = idx;
    }

    if ((i4 < 6) || (ICD_state->V_win[9] > ICD_param->VT_thresh)) {
      ICD_state->VTduration = 0.0;
      *inhibit = 1.0;

      //  message=[message;{['t=',num2str(ICD_state.g_clk),',VT duration drop-off']}]; 
    }

    //  Duration finishes
    if (ICD_state->VTdur_count >= ICD_param->VTdur_length) {
      ICD_state->VTduration = 0.0;
      ICD_state->VTdur_count = 0.0;

      //  If less than 6/10 beats during duration or the last beat is slower
      //  than VT threshold, cancel episode.
      for (idx = 0; idx < 10; idx++) {
        x[idx] = (ICD_state->V_win[idx] < ICD_param->VT_thresh);
      }

      idx = 0;
      ii = 1;
      exitg3 = false;
      while ((!exitg3) && (ii < 11)) {
        guard3 = false;
        if (x[ii - 1]) {
          idx++;
          if (idx >= 10) {
            exitg3 = true;
          } else {
            guard3 = true;
          }
        } else {
          guard3 = true;
        }

        if (guard3) {
          ii++;
        }
      }

      if (1 > idx) {
        i5 = 0;
      } else {
        i5 = idx;
      }

      if ((i5 < 6) || (ICD_state->V_win[9] > ICD_param->VT_thresh)) {
        //  Do nothing, cancel episode
        //  message=[message;{['t=',num2str(ICD_state.g_clk),',VT duration finish but inhibit']}]; 
      } else {
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%
        //  discriminators decisions
        // %%%%%%%%%%%%%%%%%%%%%%%%%
        fcc = ICD_state->A_win[0];
        y = ICD_state->V_win[0];
        for (idx = 0; idx < 9; idx++) {
          fcc += ICD_state->A_win[idx + 1];
          y += ICD_state->V_win[idx + 1];
        }

        s = 0.0;
        for (idx = 0; idx < 10; idx++) {
          b_x[idx] = ICD_state->V_win[idx];
          s += ICD_state->V_win[idx];
        }

        s /= 10.0;
        d = 0.0;
        for (idx = 0; idx < 10; idx++) {
          c_x = b_x[idx] - s;
          d += c_x * c_x;
        }

        if (dis_VgtA(fcc / 10.0, y / 10.0)) {
          *therapy = 1.0;

          //  message=[message;{['t=',num2str(ICD_state.g_clk),',V>A therapy']}]; 
        } else if (dis_VTC(ICD_state->VTC_win)) {
          *inhibit = 1.0;

          //  message=[message;{['t=',num2str(ICD_state.g_clk),',V<A and VTC correlate inhibit']}]; 
        } else if (dis_AFib(ICD_state->A_win, ICD_param->AFib_thresh) && dis_STB
                   (d / 9.0)) {
          *inhibit = 1.0;

          //   message=[message;{['t=',num2str(ICD_state.g_clk),',V<A & VTC not correlate & AF STB inhibit']}]; 
        } else {
          *therapy = 1.0;

          //   message=[message;{['t=',num2str(ICD_state.g_clk),',V<A & VTC not correlate & AF STB therapy']}]; 
        }
      }
    }
  }

  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  //  Detection
  // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if (A_sense != 0.0) {
    //  Slide sensing window
    //           ICD_state.A_win(1)=[];
    //           ICD_state.A_win=[ICD_state.A_win;ICD_state.A_clk];
    for (idx = 0; idx < 9; idx++) {
      ICD_state->A_win[idx] = ICD_state->A_win[1 + idx];
    }

    ICD_state->A_win[9] = ICD_state->A_clk;

    //  Reset clock
    ICD_state->A_clk = 0.0;

    //  Atrial refractory within PVARP
    if ((ICD_state->V_clk > ICD_param->PVAB) && (ICD_state->V_clk <
         ICD_param->PVARP)) {
      ICD_state->AR = 1.0;
    } else {
      //  Atrial sense after PVARP
      //    if ICD_state.V_clk>ICD_param.PVARP
      ICD_state->AS = 1.0;

      //  end
    }
  }

  if (V_sense != 0.0) {
    //  Slide sensing window
    //           ICD_state.V_win(1)=[];
    //           ICD_state.V_win=[ICD_state.V_win;ICD_state.V_clk];
    for (idx = 0; idx < 9; idx++) {
      ICD_state->V_win[idx] = ICD_state->V_win[1 + idx];
    }

    ICD_state->V_win[9] = ICD_state->V_clk;

    //  Slide Morphology window
    for (idx = 0; idx < 9; idx++) {
      ICD_state->VTC_win[idx] = ICD_state->VTC_win[1 + idx];
    }

    // ICD_state.VTC_win=[ICD_state.VTC_win;V_sense];
    //  Two-zone configuration with VT/VF
    //           if ICD_param.zone_num==2
    //  VT
    if ((ICD_state->V_clk < ICD_param->VT_thresh) && (ICD_state->V_clk >=
         ICD_param->VF_thresh)) {
      ICD_state->VT = 1.0;
    }

    //  VF
    if (ICD_state->V_clk < ICD_param->VF_thresh) {
      ICD_state->VF = 1.0;
    }

    //  VS
    if (ICD_state->V_clk >= ICD_param->VT_thresh) {
      ICD_state->VS = 1.0;
    }

    //  Initial detection for VT/VF
    //  8/10 V intervals and the last V interval less than VF
    //  threshold. VF is prioritized
    guard1 = false;
    if (ICD_state->VFduration == 0.0) {
      for (idx = 0; idx < 10; idx++) {
        x[idx] = (ICD_state->V_win[idx] < ICD_param->VF_thresh);
      }

      idx = 0;
      ii = 1;
      exitg2 = false;
      while ((!exitg2) && (ii < 11)) {
        guard2 = false;
        if (x[ii - 1]) {
          idx++;
          if (idx >= 10) {
            exitg2 = true;
          } else {
            guard2 = true;
          }
        } else {
          guard2 = true;
        }

        if (guard2) {
          ii++;
        }
      }

      if (1 > idx) {
        i6 = 0;
      } else {
        i6 = idx;
      }

      if ((i6 >= 8) && (ICD_state->V_win[9] < ICD_param->VF_thresh)) {
        //  VFduration starts
        ICD_state->VFduration = 1.0;
        ICD_state->VFdur_count = 0.0;

        //                   message=[message;{['t=',num2str(ICD_state.g_clk),',VF duration start']}]; 
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%
        //  To do
        // %%%%%%%%%%%%%%%%%%%%%%%%%%%
        //  Episode start and marker recording
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      //  8/10 V intervals and the last V interval less than VT
      //  threshold
      if (ICD_state->VTduration == 0.0) {
        for (idx = 0; idx < 10; idx++) {
          x[idx] = (ICD_state->V_win[idx] < ICD_param->VT_thresh);
        }

        idx = 0;
        ii = 1;
        exitg1 = false;
        while ((!exitg1) && (ii < 11)) {
          b_guard1 = false;
          if (x[ii - 1]) {
            idx++;
            if (idx >= 10) {
              exitg1 = true;
            } else {
              b_guard1 = true;
            }
          } else {
            b_guard1 = true;
          }

          if (b_guard1) {
            ii++;
          }
        }

        if (1 > idx) {
          i7 = 0;
        } else {
          i7 = idx;
        }

        if ((i7 >= 8) && (ICD_state->V_win[9] < ICD_param->VT_thresh)) {
          //  VTduration starts
          ICD_state->VTduration = 1.0;
          ICD_state->VTdur_count = 0.0;

          //                       message=[message;{['t=',num2str(ICD_state.g_clk),',VT duration start']}]; 
        }
      }
    }

    //           else
    //               if ICD_param.zone_num==1
    //                   %%%%%%%%%%%%%%%%%%%%%%%%
    //                   % todo
    //                   %%%%%%%%%%%%%%%%%%%%%%%%
    //               end
    //               if ICD_param.zone_num==3
    //                   %%%%%%%%%%%%%%%%%%%%%%%%
    //                   % todo
    //                   %%%%%%%%%%%%%%%%%%%%%%%%
    //               end
    //           end
    //  Reset clock
    ICD_state->V_clk = 0.0;
  }
}

//
// File trailer for ICD_BS.cpp
//
// [EOF]
//
