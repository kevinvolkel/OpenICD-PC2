//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ICD_sensing_BS_A.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 28-Mar-2016 15:53:45
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_sensing_BS.h"
#include "ICD_sensing_BS_A.h"
#include "ICD_sensing_BS_V.h"
#include "ICD_sensing_init_BS.h"

// Function Definitions

//
// Arguments    : struct0_T *ICD_sense_state
//                struct1_T *ICD_sense_param
//                double b_signal
//                double *Asignal
//                double *V_in
//                double *A_in
//                double *A_blank
// Return Type  : void
//
void ICD_sensing_BS_A(struct0_T *ICD_sense_state, struct1_T *ICD_sense_param,
                      double b_signal, double *Asignal, double *V_in, double
                      *A_in, double *A_blank)
{
  double mtmp;
  double varargin_1_idx_1;
  int ixstart;
  int ix;
  boolean_T exitg1;

  // ICD Sensing Function
  // input: TBD
  //  % parameter struct
  //  (initial settings)
  // ICD_sense_state
  // State: 1 - sensing/AGC
  //        2 - peak tracking
  //        3 - absolute blanking
  //        4 - noise window
  //        5 - fixed refractory
  //  ICD_sense_state.State=1;
  //  ICD_sense_state.VPace=0;
  //  ICD_sense_state.VSense=0;
  //  ICD_sense_state.APace=0;
  //  ICD_sense_state.ASense=0;
  //  ICD_sense_state.StateClock=0;
  //  ICD_sense_state.StateClockLim=0;
  //  ICD_sense_state.RefPeriodClock=0;
  //  ICD_sense_state.VThres=vThresMin;
  //  ICD_sense_state.VType=1;
  //  ICD_sense_state.VAvg=vThresMin;%TODO: could be different initial value
  //  ICD_sense_state.DebugClock=0;
  //  current state
  //  current waveform sample (vector)
  // output: TBD
  //  input waveform
  //  current threshold
  // TODO: what happens when there is a VPACE event, but it is not sensed?
  *V_in = 0.0;
  *A_in = 0.0;
  *A_blank = 0.0;
  *Asignal = fabs(b_signal);
  ICD_sense_state->DebugClock++;
  ICD_sense_param->DebugClock++;

  // Assumptions
  // If there is a VSense, no matter the state, will go into smartsense
  // After blanking, reset AGC to 3/8 --> compass book
  // TODO: It could be possible to do a different fixed cross-chamber blanking
  // rather than "SMARTSensing"
  if ((ICD_sense_state->VSense == 1.0) || ((ICD_sense_state->VPace == 1.0) &&
       (ICD_sense_state->AState != 6.0))) {
    ICD_sense_state->AState = 6.0;
    ICD_sense_state->AAGCOn = 0.0;
    if (ICD_sense_state->VSense == 1.0) {
      ICD_sense_state->VSense = 0.0;
      ICD_sense_state->AStateClock = 0.0;
      ICD_sense_state->AStateClockLim = ICD_sense_param->ACCBlankPeriod;
      ICD_sense_state->PrevA = ICD_sense_state->AThres;
    }

    // assuming that in the case that there is a vsense as well as a vpace,
    // preference will be given to the pace
    if (ICD_sense_state->VPace == 1.0) {
      ICD_sense_state->VPace = 0.0;

      // TODO: Something for adjust for VPACE, for now just keep same
      ICD_sense_state->AStateClock = 0.0;
      ICD_sense_state->AStateClockLim = ICD_sense_param->ACCBlankPeriod;
    }
  }

  // Sensing
  if (ICD_sense_state->AState == 1.0) {
    if (*Asignal >= ICD_sense_state->AThres) {
      ICD_sense_state->AState = 2.0;
      ICD_sense_state->AStateClock = 0.0;
      ICD_sense_state->AStateClockLim = ICD_sense_param->AAbsBlankPeriod;
      ICD_sense_state->AAGCOn = 0.0;
      if (ICD_sense_state->APace == 0.0) {
        ICD_sense_state->ASense = 1.0;
        *A_in = 1.0;
      }

      if (ICD_sense_state->APace == 0.0) {
        ICD_sense_state->AType = 1.0;
      } else {
        ICD_sense_state->AType = 2.0;
      }
    } else {
      ICD_sense_state->AStateClock++;
    }

    // PeakTracking
  } else if (ICD_sense_state->AState == 2.0) {
    ICD_sense_state->AStateClock++;
    if (ICD_sense_state->ASense == 1.0) {
      ICD_sense_state->ASense = 0.0;
    }

    if (b_signal < ICD_sense_state->AThres) {
      ICD_sense_state->AStateClock = 0.0;
      ICD_sense_state->AStateClockLim = ICD_sense_param->AAbsBlankPeriod;
      ICD_sense_state->AState = 3.0;

      // update peak
      // ICD_sense_state.AAvg=ICD_sense_state.AAvg*(3/4)+signal*(1/4);
      ICD_sense_state->AAvg = ICD_sense_state->AAvg * 0.75 +
        ICD_sense_state->AThres * 0.25;
      ICD_sense_state->PrevA = ICD_sense_state->AThres;
      mtmp = ICD_sense_state->AAvg * 0.125;
      varargin_1_idx_1 = ICD_sense_param->AAGCNomThres;
      ixstart = 1;
      if (rtIsNaN(mtmp)) {
        ix = 2;
        exitg1 = false;
        while ((!exitg1) && (ix < 3)) {
          ixstart = 2;
          if (!rtIsNaN(varargin_1_idx_1)) {
            mtmp = varargin_1_idx_1;
            exitg1 = true;
          } else {
            ix = 3;
          }
        }
      }

      if ((ixstart < 2) && (varargin_1_idx_1 > mtmp)) {
        mtmp = varargin_1_idx_1;
      }

      ICD_sense_state->AThresMin = mtmp;
      ICD_sense_state->AThresMax = ICD_sense_state->AAvg * 1.5;
    } else {
      // while peak is going up
      ICD_sense_state->AThres = b_signal;
    }

    // AbsoluteBlanking
  } else if (ICD_sense_state->AState == 3.0) {
    if (ICD_sense_state->AStateClock >= ICD_sense_state->AStateClockLim) {
      ICD_sense_state->AStateClock = 0.0;
      ICD_sense_state->AStateClockLim = ICD_sense_param->ANoiseWindow;

      // ICD_sense_state.VThres=ICD_sense_state.VThres*.75;
      ICD_sense_state->AState = 4.0;
    } else {
      ICD_sense_state->AStateClock++;
    }

    // Noise window
  } else if (ICD_sense_state->AState == 4.0) {
    if (ICD_sense_state->AStateClock >= ICD_sense_state->AStateClockLim) {
      ICD_sense_state->AStateClock = 0.0;
      ICD_sense_state->AStateClockLim = ICD_sense_param->AFixedRefPeriod;
      ICD_sense_state->AState = 5.0;
    } else {
      // TODO: something to repeat noise window is noise detected
      ICD_sense_state->AStateClock++;
    }

    // Fixed Refractory
  } else if (ICD_sense_state->AState == 5.0) {
    if (ICD_sense_state->AStateClock >= ICD_sense_state->AStateClockLim) {
      ICD_sense_state->AThres *= 0.75;
      ICD_sense_state->AStateClock = 0.0;
      if (ICD_sense_state->AType == 1.0) {
        ICD_sense_state->AAGCClockLim = ICD_sense_param->ASAGCPeriod;
      } else {
        if (ICD_sense_state->AType == 2.0) {
          ICD_sense_state->AAGCClockLim = ICD_sense_param->APAGCPeriod;
        }
      }

      ICD_sense_state->AStateClockLim = ICD_sense_param->AFixedRefPeriod;
      ICD_sense_state->AState = 1.0;
      ICD_sense_state->AAGCOn = 1.0;
      ICD_sense_state->AAGCClock = 0.0;

      // V_in=1;
    } else {
      // TODO: something to during fixed refractory
      ICD_sense_state->AStateClock++;
    }

    // Smart cross-chamber blanking
  } else {
    if (ICD_sense_state->AState == 6.0) {
      if (ICD_sense_state->AStateClock >= ICD_sense_state->AStateClockLim) {
        // restart AGC at 3/8 previous A Peak
        ICD_sense_state->AThres = ICD_sense_state->PrevA * 0.375;
        if (ICD_sense_state->AThres <= ICD_sense_state->AThresMin) {
          ICD_sense_state->AThres = ICD_sense_state->AThresMin;
        }

        if (ICD_sense_state->AType == 1.0) {
          ICD_sense_state->AStateClockLim = ICD_sense_param->ASAGCPeriod;
          ICD_sense_state->AAGCClockLim = ICD_sense_param->ASAGCPeriod;
        } else {
          if (ICD_sense_state->AType == 2.0) {
            ICD_sense_state->AStateClockLim = ICD_sense_param->APAGCPeriod;
            ICD_sense_state->AAGCClockLim = ICD_sense_param->APAGCPeriod;
          }
        }

        // Change state back to 1
        ICD_sense_state->AState = 1.0;

        // restart AGC Clock
        ICD_sense_state->AAGCClock = 0.0;
        ICD_sense_state->AStateClock = 0.0;
        ICD_sense_state->AAGCOn = 1.0;
      } else {
        ICD_sense_state->AStateClock++;
        *A_blank = ICD_sense_state->AThres;
      }
    }
  }

  // AGC
  if (ICD_sense_state->AAGCOn == 1.0) {
    ICD_sense_state->AAGCClock++;
    if (ICD_sense_state->AAGCClock >= ICD_sense_state->AAGCClockLim) {
      // check if minimum threshold
      ICD_sense_state->AAGCClock = 0.0;
      ICD_sense_state->AThres *= 0.875;
      if (ICD_sense_state->AThres <= ICD_sense_state->AThresMin) {
        ICD_sense_state->AThres = ICD_sense_state->AThresMin;
      }

      // if(ICD_sense_state.VThres<ICD_sense_param.VThresMin)
      //     ICD_sense_state.VThres=ICD_sense_param.VThresMin;
      // end
    }
  }
}

//
// File trailer for ICD_sensing_BS_A.cpp
//
// [EOF]
//
