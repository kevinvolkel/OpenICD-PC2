//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ICD_sensing_BS_terminate.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 28-Mar-2016 15:53:45
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_sensing_BS.h"
#include "ICD_sensing_BS_A.h"
#include "ICD_sensing_BS_V.h"
#include "ICD_sensing_init_BS.h"
#include "ICD_sensing_BS_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void ICD_sensing_BS_terminate()
{
  // (no terminate code required)
}

//
// File trailer for ICD_sensing_BS_terminate.cpp
//
// [EOF]
//
