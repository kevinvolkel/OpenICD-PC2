//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ICD_sensing_BS_types.h
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 28-Mar-2016 15:53:45
//
#ifndef __ICD_SENSING_BS_TYPES_H__
#define __ICD_SENSING_BS_TYPES_H__

// Include Files
#include "rtwtypes.h"

// Type Definitions
typedef struct {
  double VState;
  double VPace;
  double VSense;
  double APace;
  double ASense;
  double VStateClock;
  double VStateClockLim;
  double VRefPeriodClock;
  double VThres; 
  double VType;
  double VAvg;
  double DebugClock;
  double VThresMax;
  double VThresMin;
  double VAGCOn;
  double VAGCClock;
  double VAGCClockLim;
  double VBuffer[3];
  double VBufInd;
  double PrevV;
  double PrevA;
  double AState;
  double AStateClock;
  double AStateClockLim;
  double ARefPeriodClock;
  double AThres;
  double AType;
  double AAvg;
  double AThresMax;
  double AThresMin;
  double AAGCOn;
  double AAGCClock;
  double AAGCClockLim;
  double ABuffer[3];
  double ABufInd;
} struct0_T;

typedef struct {
  double VAGCNomThres;
  double VRefPeriod;
  double VAbsBlankPeriod;
  double VNoiseWindow;
  double VFixedRefPeriod;
  double VSAGCPeriod;
  double VPAGCPeriod;
  double DebugClock;
  double AAGCNomThres;
  double ARefPeriod;
  double AAbsBlankPeriod;
  double ANoiseWindow;
  double AFixedRefPeriod;
  double ASAGCPeriod;
  double APAGCPeriod;
  double ACCBlankPeriod;
} struct1_T;

typedef struct {
  double refx[8];
  double refy[8];
} struct3_T;

typedef struct {
  double A_clk;
  double V_clk;
  double AS;
  double AR;
  double ABlk;
  double VS;
  double VT;
  double VF;
  double VBlk;
  double V_win[10];
  double A_win[10];
  double VTC_win[10];
  double VFduration;
  double VFdur_count;
  double VTduration;
  double VTdur_count;
  double VTC_morph[200];
  double VTC_ind;
  struct3_T NSR_temp;
} struct4_T;

typedef struct {
  double PVAB;
  double PAVB;
  double PVARP;
  double VF_thresh;
  double VT_thresh;
  double zone_num;
  double AFib_thresh;
  double VFdur_length;
  double VTdur_length;
} struct2_T;





#endif

//
// File trailer for ICD_sensing_BS_types.h
//
// [EOF]
//
