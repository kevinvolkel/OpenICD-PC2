//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: ICD_sensing_init_BS.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 28-Mar-2016 15:53:45
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_sensing_BS.h"
#include "ICD_sensing_BS_A.h"
#include "ICD_sensing_BS_V.h"
#include "ICD_sensing_init_BS.h"

// Function Definitions

//
// Arguments    : double vThresNom
//                double vAGCNomThres
//                double vRefPeriod
//                double vAbsBlankPeriod
//                double vNoiseWindow
//                double vFixedRefPeriod
//                double vsAGCPeriod
//                double vpAGCPeriod
//                double aThresNom
//                double aAGCNomThres
//                double aRefPeriod
//                double aAbsBlankPeriod
//                double aNoiseWindow
//                double aFixedRefPeriod
//                double asAGCPeriod
//                double apAGCPeriod
//                double aCCBlankPeriod
//                struct0_T *ICD_sense_state
//                struct1_T *ICD_sense_param
// Return Type  : void
//
void ICD_sensing_init_BS(double vThresNom, double vAGCNomThres, double
  vRefPeriod, double vAbsBlankPeriod, double vNoiseWindow, double
  vFixedRefPeriod, double vsAGCPeriod, double vpAGCPeriod, double aThresNom,
  double aAGCNomThres, double aRefPeriod, double aAbsBlankPeriod, double
  aNoiseWindow, double aFixedRefPeriod, double asAGCPeriod, double apAGCPeriod,
  double aCCBlankPeriod, struct0_T *ICD_sense_state, struct1_T *ICD_sense_param)
{
  int i;

  // ICD_sensing_BS_init
  // Initializes data structure which is use throughout sensing algorithm
  // ICD_sense_state
  // State: 1 - sensing/AGC
  //        2 - peak tracking
  //        3 - absolute blanking
  //        4 - noise window
  //        5 - fixed refractory
  //
  // (Flags which should be reset when output is set. Intended use is for
  // signalling different processes during the function)
  // VPace: 1 - occurred; 0 - not occurred
  // VSense: 1- occurred; 0 - not occurred
  // APace: 1- occurred; 0 - not occurred
  // ASense: 1- Sense Event; 0 - No Event (should be impulse)
  // VThres: Detection threshold (uV)
  // StateClock: Clock for time in each state;
  // RefPeriodClock: Refractory Period Clock (total time since beginning of
  // event)
  // FixedRefPeriodClock
  // VType: Type of last event (0 - no event 1 - Vsense 2 - VPace)
  // debugClock: clock used for debugging
  //
  // ICD_sense_param
  // VThresMin: current threshold minimum for ventricular sense (should start at minimum) 
  ICD_sense_state->VState = 1.0;
  ICD_sense_state->VPace = 0.0;
  ICD_sense_state->VSense = 0.0;
  ICD_sense_state->APace = 0.0;
  ICD_sense_state->ASense = 0.0;
  ICD_sense_state->VStateClock = 0.0;
  ICD_sense_state->VStateClockLim = 0.0;
  ICD_sense_state->VRefPeriodClock = 0.0;
  ICD_sense_state->VThres = vThresNom;
  ICD_sense_state->VType = 1.0;
  ICD_sense_state->VAvg = vThresNom;

  // TODO: could be different initial value
  ICD_sense_state->VThresMax = vThresNom * 1.5;
  ICD_sense_state->VThresMin = vAGCNomThres;
  ICD_sense_state->VAGCOn = 1.0;
  ICD_sense_state->VAGCClock = 0.0;
  ICD_sense_state->VAGCClockLim = vsAGCPeriod;

  // TODO: Buffer
  ICD_sense_state->VBufInd = 1.0;
  ICD_sense_state->PrevV = 0.0;
  ICD_sense_state->PrevA = 0.0;
  ICD_sense_param->VAGCNomThres = vAGCNomThres;
  ICD_sense_param->VRefPeriod = vRefPeriod;
  ICD_sense_param->VAbsBlankPeriod = vAbsBlankPeriod;
  ICD_sense_param->VNoiseWindow = vNoiseWindow;
  ICD_sense_param->VFixedRefPeriod = vFixedRefPeriod;
  ICD_sense_param->VSAGCPeriod = vsAGCPeriod;
  ICD_sense_param->VPAGCPeriod = vpAGCPeriod;

  // TODO should be dynamically adjusted
  // Sense state for atrial
  ICD_sense_state->AState = 1.0;
  ICD_sense_state->AStateClock = 0.0;
  ICD_sense_state->AStateClockLim = 0.0;
  ICD_sense_state->ARefPeriodClock = 0.0;
  ICD_sense_state->AThres = aThresNom;
  ICD_sense_state->AType = 1.0;
  ICD_sense_state->AAvg = aThresNom;

  // TODO: could be different initial value
  ICD_sense_state->DebugClock = 0.0;
  ICD_sense_state->AThresMax = aThresNom * 1.5;
  ICD_sense_state->AThresMin = aAGCNomThres;
  ICD_sense_state->AAGCOn = 1.0;
  ICD_sense_state->AAGCClock = 0.0;
  ICD_sense_state->AAGCClockLim = asAGCPeriod;

  // TODO: Buffer
  for (i = 0; i < 3; i++) {
    ICD_sense_state->VBuffer[i] = 0.0;
    ICD_sense_state->ABuffer[i] = 0.0;
  }

  ICD_sense_state->ABufInd = 1.0;

  // Sense param for atrial
  ICD_sense_param->AAGCNomThres = aAGCNomThres;
  ICD_sense_param->ARefPeriod = aRefPeriod;
  ICD_sense_param->AAbsBlankPeriod = aAbsBlankPeriod;
  ICD_sense_param->ANoiseWindow = aNoiseWindow;
  ICD_sense_param->AFixedRefPeriod = aFixedRefPeriod;
  ICD_sense_param->ASAGCPeriod = asAGCPeriod;
  ICD_sense_param->APAGCPeriod = apAGCPeriod;

  // TODO should be dynamically adjusted
  ICD_sense_param->DebugClock = 0.0;
  ICD_sense_param->ACCBlankPeriod = aCCBlankPeriod;
}

//
// File trailer for ICD_sensing_init_BS.cpp
//
// [EOF]
//
