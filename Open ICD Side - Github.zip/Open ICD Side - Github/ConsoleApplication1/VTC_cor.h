//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VTC_cor.h
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//
#ifndef __VTC_COR_H__
#define __VTC_COR_H__

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ICD_sensing_BS_types.h"

// Function Declarations
extern void VTC_cor(const double VTC_morph[200], const struct3_T *NSR_temp,
                    double *V_morph, double *fcc);

#endif

//
// File trailer for VTC_cor.h
//
// [EOF]
//
