//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: dis_AFib.h
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//
#ifndef __DIS_AFIB_H__
#define __DIS_AFIB_H__

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ICD_sensing_BS_types.h"

// Function Declarations
extern boolean_T dis_AFib(const double A_win[10], double AF_thresh);

#endif

//
// File trailer for dis_AFib.h
//
// [EOF]
//
