//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: dis_AFib_types.h
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//
#ifndef __DIS_AFIB_TYPES_H__
#define __DIS_AFIB_TYPES_H__

// Include Files
#include "rtwtypes.h"

// Type Definitions
typedef struct {
  double refx[8];
  double refy[8];
} struct1_T;

typedef struct {
  double A_clk;
  double V_clk;
  double AS;
  double AR;
  double ABlk;
  double VS;
  double VT;
  double VF;
  double VBlk;
  double V_win[10];
  double A_win[10];
  double VTC_win[10];
  double VFduration;
  double VFdur_count;
  double VTduration;
  double VTdur_count;
  double VTC_morph[200];
  double VTC_ind;
  struct1_T NSR_temp;
} struct0_T;

typedef struct {
  double PVAB;
  double PAVB;
  double PVARP;
  double VF_thresh;
  double VT_thresh;
  double zone_num;
  double AFib_thresh;
  double VFdur_length;
  double VTdur_length;
} struct2_T;

#endif

//
// File trailer for dis_AFib_types.h
//
// [EOF]
//
