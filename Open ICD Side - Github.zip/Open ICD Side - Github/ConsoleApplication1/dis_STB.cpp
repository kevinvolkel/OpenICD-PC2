//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: dis_STB.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_BS.h"
#include "VTC_cor.h"
#include "dis_AFib.h"
#include "dis_STB.h"
#include "dis_VTC.h"
#include "dis_VgtA.h"

// Function Definitions

//
// Arguments    : double covV
// Return Type  : boolean_T
//
boolean_T dis_STB(double covV)
{
  return !(covV > 20.0);
}

//
// File trailer for dis_STB.cpp
//
// [EOF]
//
