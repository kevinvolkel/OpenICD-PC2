//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: dis_VTC.cpp
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//

// Include Files
#include "rt_nonfinite.h"
#include "ICD_BS.h"
#include "VTC_cor.h"
#include "dis_AFib.h"
#include "dis_STB.h"
#include "dis_VTC.h"
#include "dis_VgtA.h"

// Function Definitions

//
// Arguments    : const double VTC_win[10]
// Return Type  : boolean_T
//
boolean_T dis_VTC(const double VTC_win[10])
{
  int idx;
  int ii;
  boolean_T exitg1;
  boolean_T guard1 = false;
  int i1;
  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii < 11)) {
    guard1 = false;
    if (VTC_win[ii - 1] == 1.0) {
      idx++;
      if (idx >= 10) {
        exitg1 = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      ii++;
    }
  }

  if (1 > idx) {
    i1 = 0;
  } else {
    i1 = idx;
  }

  return i1 >= 3;
}

//
// File trailer for dis_VTC.cpp
//
// [EOF]
//
