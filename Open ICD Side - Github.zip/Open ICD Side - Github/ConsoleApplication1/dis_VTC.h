//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: dis_VTC.h
//
// MATLAB Coder version            : 3.0
// C/C++ source code generated on  : 05-Apr-2016 15:21:22
//
#ifndef __DIS_VTC_H__
#define __DIS_VTC_H__

// Include Files
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "ICD_sensing_BS_types.h"

// Function Declarations
extern boolean_T dis_VTC(const double VTC_win[10]);

#endif

//
// File trailer for dis_VTC.h
//
// [EOF]
//
