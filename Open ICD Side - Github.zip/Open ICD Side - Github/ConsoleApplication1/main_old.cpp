#include <Engine.h>
#include "ICD_sensing_init_BS.h"
#include  "ICD_sensing_BS.h"
#include "ICD_BS.h"
#include <iostream>
#include <string>
#include <cmath>
#include <math.h>
#include <NIDAQmx.h>
#include <stdio.h>
#include <thread>
#include <chrono>
#include <ctime>
#include <process.h>   //reqd. for system function prototype    
#include <stdlib.h>     /* system, NULL, EXIT_FAILURE */
#include <Tchar.h>
#include <windows.h>
#include <conio.h>
#include <fstream>

#pragma comment (lib, "libmat.lib")
#pragma comment (lib, "libmx.lib")
#pragma comment (lib, "libmex.lib")
#pragma comment (lib, "libeng.lib")

using namespace std;

struct0_T  icd_sense_st;
struct1_T  icd_sense_par;
struct2_T  icd_par;
struct3_T  NSR_template;
struct4_T  icd_st;

bool new_data_event = false; 
float64 input_data_buffer_A[50000] = { 0 };
float64 input_data_buffer_V[50000] = { 0 };
float64 input_data_buffer_S[50000] = { 0 };

int input_data_buffer_idx = 0;
int input_data_reading_idx = 0;

const int arraysize = 10000;
const  double degTorad = 0.0174;

double theraphy_sign = 0;
double inhibit_sign = 0;

double vThresNom, vAGCNomThres, vRefPeriod, vAbsBlankPeriod,
vNoiseWindow, vFixedRefPeriod, vsAGCPeriod, vpAGCPeriod,
aThresNom, aAGCNomThres, aRefPeriod, aAbsBlankPeriod,
aNoiseWindow, aFixedRefPeriod, asAGCPeriod, apAGCPeriod, aCCBlockPeriod;
double V_input, A_input, A_BlanckP;

double initParams[17] = { 0 };

double input_signals_sensing[2] = { 0 };
double input_shock_signal = 0;

char shock = 0;
bool writing_data = false;
long int print_idx = 0;

int DAQ1_thread() {

	int32       error = 0;
	TaskHandle  taskHandle = 0;
	TaskHandle  taskHandle2 = 0;

	float64     data[2] = { 0 };
	float64     data2[2] = { 0 };

	char        errBuff[2048] = { '\0' };
	char        errBuff2[2048] = { '\0' };

	std::string filename;
	std::ofstream writeOut;

	filename = "output.out";
	//filename += ".out"; //here

	writeOut.open(filename.c_str(), ios_base::trunc | ios_base::out);
	writeOut.setf(ios::fixed, ios::floatfield);
	writeOut.precision(4);
	writeOut.flush();
	writeOut << "VRAW \t ARAW \t SRAW \n";



#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else
	int32 CVICALLBACK EveryNCallback(TaskHandle taskHandle, int32 everyNsamplesEventType, uInt32 nSamples, void *callbackData);
	int32 CVICALLBACK DoneCallback(TaskHandle taskHandle, int32 status, void *callbackData);

	/*********************************************/
	// DAQmx Configure Code
	/*********************************************/
	DAQmxCreateTask("SHOCK", &taskHandle);
	DAQmxCreateAOVoltageChan(taskHandle, "Dev2/ao0", "", -10.0, 10.0, DAQmx_Val_Volts, "");

	DAQmxCreateTask("ACQUIRE", &taskHandle2);
	DAQmxCreateAIVoltageChan(taskHandle2, "Dev2/ai0", "1", DAQmx_Val_RSE, -10.0, 10.0, DAQmx_Val_Volts, NULL);
	DAQmxCreateAIVoltageChan(taskHandle2, "Dev2/ai1", "2", DAQmx_Val_RSE, -10.0, 10.0, DAQmx_Val_Volts, NULL);
	DAQmxCreateAIVoltageChan(taskHandle2, "Dev2/ai2", "3", DAQmx_Val_RSE, -10.0, 10.0, DAQmx_Val_Volts, NULL);
	DAQmxCfgSampClkTiming(taskHandle2, "", 1000, DAQmx_Val_Rising, DAQmx_Val_ContSamps, 1);
	DAQmxRegisterEveryNSamplesEvent(taskHandle2, DAQmx_Val_Acquired_Into_Buffer, 1, 0, EveryNCallback, NULL);
	DAQmxRegisterDoneEvent(taskHandle2, 0, DoneCallback, NULL);

	/*********************************************/
	// DAQmx Start Code
	/*********************************************/
	DAQmxStartTask(taskHandle);
	DAQmxStartTask(taskHandle2);
	while (1) {
		 while (new_data_event == false); 
		 writeOut << input_data_buffer_A[input_data_reading_idx] << '\t' << input_data_buffer_V[input_data_reading_idx] << '\t' << input_data_buffer_S[input_data_reading_idx] << endl;
		 printf("r idx %i\t d1 %f\t d2 %f\t d3 %f \n",input_data_buffer_idx, input_data_buffer_A[input_data_reading_idx], input_data_buffer_V[input_data_reading_idx], input_data_buffer_S[input_data_reading_idx]);
					
			//input_signals_sensing[0] = input_data_buffer_A[input_data_reading_idx];
			//input_signals_sensing[1] = input_data_buffer_V[input_data_reading_idx];
			//input_shock_signal = input_data_buffer_S[input_data_reading_idx];
			//ICD_sensing_BS(&icd_sense_st, &icd_sense_par, input_signals_sensing, &V_input, &A_input, &A_BlanckP);
			//ICD_BS(&icd_st, &icd_par, A_input, V_input, input_data_buffer_S[input_data_reading_idx], &theraphy_sign, &inhibit_sign);

			input_data_reading_idx++;
			new_data_event = false;


			if (shock == 0) {
				data[0] = 0;
				DAQmxWriteAnalogF64(taskHandle, 1, 1, 10.0, DAQmx_Val_GroupByChannel, data, NULL, NULL);

			}
			else {
				data[0] = 2;
				DAQmxWriteAnalogF64(taskHandle, 1, 1, 10.0, DAQmx_Val_GroupByChannel, data, NULL, NULL);
			}
		}
	
	return 0;
}

int main() {

	Engine *m_pEngine;
	m_pEngine = engOpen("null");

	double SinArray[arraysize];
	double CosArray[arraysize];
	double Degrees[arraysize];



	for (int iii = 0; iii < arraysize; iii++) {
		Degrees[iii] = iii;
		SinArray[iii] = sin(iii*degTorad);
		CosArray[iii] = cos(iii*degTorad);

	}

	mxArray* dSIN = mxCreateDoubleMatrix(1, 1, mxREAL);
	mxArray* dCOS = mxCreateDoubleMatrix(1, 1, mxREAL);
	mxArray* dDEG = mxCreateDoubleMatrix(1, 1, mxREAL);

	double* pSIN = mxGetPr(dSIN);
	double* pCOS = mxGetPr(dCOS);
	double* pDEG = mxGetPr(dDEG);

	ICD_sensing_init_BS(
		initParams[0],
		initParams[1],
		initParams[2],
		initParams[3],
		initParams[4],
		initParams[5],
		initParams[6],
		initParams[7],
		initParams[8],
		initParams[9],
		initParams[10],
		initParams[11],
		initParams[12],
		initParams[13],
		initParams[14],
		initParams[15],
		initParams[16],
		&icd_sense_st, &icd_sense_par);

	icd_par.PVAB = 50;
	icd_par.PAVB = 40;
	icd_par.PVARP = 200;
	icd_par.VF_thresh = 320;
	icd_par.VT_thresh = 400;
	icd_par.zone_num = 2;
	icd_par.AFib_thresh = 200;
	icd_par.VFdur_length = 3000;
	icd_par.VTdur_length = 3000;


	icd_st.A_clk = 0;
	icd_st.V_clk = 0;
	icd_st.AS = 0;
	icd_st.AR = 0;
	icd_st.ABlk = 0;
	icd_st.VS = 0;
	icd_st.VT = 0;
	icd_st.VF = 0;
	icd_st.VBlk = 0;


	icd_st.VFduration = 0;
	icd_st.VFdur_count = 0;
	icd_st.VTduration = 0;
	icd_st.VTdur_count = 0;

	icd_st.VTC_ind = 1;


	for (int idx_st_VA = 0; idx_st_VA < 10; idx_st_VA++) {

		icd_st.V_win[idx_st_VA] = 1000000000;
		icd_st.A_win[idx_st_VA] = 1000000000;
		icd_st.VTC_win[idx_st_VA] = 1;
	}

	for (int idx_st_morph = 0; idx_st_morph < 200; idx_st_morph++) {
		icd_st.VTC_morph[idx_st_morph] = 0;
	}

	icd_st.NSR_temp.refx[0] = 1;
	icd_st.NSR_temp.refx[1] = 26;
	icd_st.NSR_temp.refx[2] = 51;
	icd_st.NSR_temp.refx[3] = 76;
	icd_st.NSR_temp.refx[4] = 101;
	icd_st.NSR_temp.refx[5] = 126;
	icd_st.NSR_temp.refx[6] = 151;
	icd_st.NSR_temp.refx[7] = 176;


	icd_st.NSR_temp.refy[0] = 0.0213233080846678;	icd_st.NSR_temp.refy[1] = 0.0234677138934066;	icd_st.NSR_temp.refy[2] = 0.0187916012571564;
	icd_st.NSR_temp.refy[3] = -0.130124304654564;   icd_st.NSR_temp.refy[4] = 0.749136905185556;	icd_st.NSR_temp.refy[5] = 0.407976438400001;
	icd_st.NSR_temp.refy[6] = 0.841403411960980;	icd_st.NSR_temp.refy[7] = 0.707817267523610;

	std::thread t1(DAQ1_thread);

	for (int iii = 0; iii < arraysize; iii++) {

		if (iii % 18 == 1) {
			*pSIN = SinArray[iii];
			*pCOS = CosArray[iii];
			*pDEG = Degrees[iii];

			engPutVariable(m_pEngine, "dSIN", dSIN);
			engPutVariable(m_pEngine, "dCOS", dCOS);
			engPutVariable(m_pEngine, "dDEG", dDEG);
			engEvalString(m_pEngine, "subplot(1, 2, 1)");
			engEvalString(m_pEngine, "scatter(dDEG,dSIN,'r','filled'),set(gca,'YLim',[-1.1 1.1],'XLim',[0 5000]), hold on,");
			engEvalString(m_pEngine, "subplot(1, 2, 2)");
			engEvalString(m_pEngine, "scatter(dDEG,dCOS,'b','filled'),set(gca,'YLim',[-1.1 1.1],'XLim',[0 5000]), hold on,");
		}


	}

	
	engEvalString(m_pEngine, "close;");
   
	while (1);

	return 1;
}

int32 CVICALLBACK EveryNCallback(TaskHandle taskHandle, int32 everyNsamplesEventType, uInt32 nSamples, void *callbackData)
{
	int32       error = 0;
	char        errBuff[2048] = { '\0' };
	static int  totalRead = 0;
	int32       read = 0;
	float64     puppa[1000];



	/*********************************************/
	// DAQmx Read Code
	/*********************************************/
	DAQmxReadAnalogF64(taskHandle, 1, 10.0, DAQmx_Val_GroupByScanNumber, puppa, 3, &read, NULL);
	if (read > 0) {
		printf("a idx %i\t d1 %f\t d2 %f\t d3 %f\n", print_idx, puppa[0],puppa[1],puppa[2]);
		input_data_buffer_A[input_data_buffer_idx] = puppa[0];
		input_data_buffer_V[input_data_buffer_idx] = puppa[1];
		input_data_buffer_S[input_data_buffer_idx] = puppa[2];
		new_data_event = true;
		while (new_data_event == true); // Waits the main program to have completed the writing procedure 
		print_idx ++ ; 
		input_data_buffer_idx++;
		if (puppa[0] > 1) shock = 0;
		else shock = 1;	
		return 1;
	}
	else return 0;
}

int32 CVICALLBACK DoneCallback(TaskHandle taskHandle, int32 status, void *callbackData)
{
	int32   error = 0;
	char    errBuff[2048] = { '\0' };

Error:
	if (DAQmxFailed(error)) {
		DAQmxGetExtendedErrorInfo(errBuff, 2048);
		DAQmxClearTask(taskHandle);
		printf("DAQmx Error: %s\n", errBuff);
	}
	return 0;
}